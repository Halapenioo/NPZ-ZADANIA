import java.util.Scanner;

public class Main {

    // Metoda zwracająca ocenę słowną
    public static String ocenaSlowna(int ocena) {
        switch (ocena) {
            case 5:
                return "bardzo dobry";
            case 4:
                return "dobry";
            case 3:
                return "dostateczny";
            case 2:
                return "niedostateczny";
            default:
                return "Nieznana ocena";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj ocenę (2–5): ");
        int ocena = scanner.nextInt();

        String wynik = ocenaSlowna(ocena);
        System.out.println("Ocena słowna: " + wynik);

        scanner.close();
    }
}
