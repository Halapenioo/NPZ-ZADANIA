import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pobieranie zmiennej x od użytkownika
        System.out.print("Podaj wartość x (liczba rzeczywista): ");
        double x = scanner.nextDouble();

        // 1. x + 1/x
        if (x != 0) {
            double wyrazenie1 = x + 1 / x;
            System.out.println("x + 1/x = " + wyrazenie1);
        } else {
            System.out.println("Nie można obliczyć x + 1/x – dzielenie przez zero.");
        }

        // 2. sin(2x) + cos^2(x)
        double wyrazenie2 = Math.sin(2 * x) + Math.pow(Math.cos(x), 2);
        System.out.println("sin(2x) + cos^2(x) = " + wyrazenie2);

        // 3. sqrt(x^2 + 3x - 8)
        double wyrazenie3podpierw = x * x + 3 * x - 8;
        if (wyrazenie3podpierw >= 0) {
            double wyrazenie3 = Math.sqrt(wyrazenie3podpierw);
            System.out.println("√(x² + 3x - 8) = " + wyrazenie3);
        } else {
            System.out.println("Nie można obliczyć pierwiastka z liczby ujemnej.");
        }

        scanner.close();
    }
}
