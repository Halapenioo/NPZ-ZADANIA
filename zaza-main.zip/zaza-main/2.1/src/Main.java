public class Main {

    public static void main(String[] args) {
        int a = 12;
        int b = 4;

        // Suma
        int suma = a + b;
        System.out.println("Suma: " + suma);

        // Różnica
        int roznica = a - b;
        System.out.println("Różnica: " + roznica);

        // Iloczyn
        int iloczyn = a * b;
        System.out.println("Iloczyn: " + iloczyn);

        // Iloraz
        int iloraz = a / b;
        System.out.println("Iloraz: " + iloraz);
    }
}
